num1 = int(input("Digite o primeiro número: "))
num2 = int(input("Digite o segundo número:  "))
num3 = int(input("Digite o terceiro número: "))

print("A soma é {}" .format(num1 + num2 + num3))