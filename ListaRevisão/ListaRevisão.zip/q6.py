vetor = list()

for i in range(10):
    number = int(input("Digite um número: "))
    vetor.append(number)
    
vetor.reverse()
print("ordem invertida:", vetor)
