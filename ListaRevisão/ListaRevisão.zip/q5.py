numbers = list()

for i in range(20):
    number = int(input("Digite um número: ")) 
    numbers.append(number)
print("O maior número é:", max(numbers))