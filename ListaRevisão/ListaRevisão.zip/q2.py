fahrenheit = float(input("Digite a temperatura em fahrenheit: "))
celsius = (fahrenheit - 32) * 5/9
print("A temperatura em Celsius é %.2f" % celsius)
